<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_3a3e4c9b87157ed7f0740d70c2a11a81'] = 'PrestaShop Connector';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_41bc4fc9efb52d522be0cb6e182cf119'] = 'Collega i siti Web di PrestaShop per la migrazione dei dati. Utilizzare solo per i moduli di migrazione PrestaShop realizzati da ETS-Soft.';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_7bcc6fa9baad6c804bd18a6a3aa7cf27'] = 'Sei sicuro di voler disinstallare PrestaShop Connector?';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_ab58af4189725736231dd0870254829f'] = 'Abilita connettore';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Abilitato';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabilitato';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_2244fb2cc638a8f0d0b9630d51c14779'] = 'URL del negozio';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_5bc7ab301074148dc708229c5ad54fc6'] = 'Token di accesso';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_0a5fa53f3f20f67f98bd6c3b16df059d'] = 'è richiesto';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_998b344cff693ad388a14ba89b1523c7'] = 'non è valido';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_a588b1abc58b8b758c4b34b69b9e10bb'] = 'Copiato';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_32b919d18cfaca89383f6000dcc9c031'] = 'Generare';
$_MODULE['<{ets_migrate_connector}prestashop>server_c10817adcfd5543bf91f627f5c9df018'] = 'Il modulo PrestaShop Connector non è stato installato nella negozio di origine';
$_MODULE['<{ets_migrate_connector}prestashop>server_f921a4cd0a24351d45ab036651b78848'] = 'Il modulo PrestaShop Connector è disabilitato.';
$_MODULE['<{ets_migrate_connector}prestashop>server_d98df3f231696c9ae7e459987ae26256'] = 'PrestaShop Connector è stato disattivato';
$_MODULE['<{ets_migrate_connector}prestashop>server_7f7dd6a7975afd2cb694aa3ebaef5c90'] = 'Il token di accesso non è corretto. Connessione negata! ';
$_MODULE['<{ets_migrate_connector}prestashop>mcdb_f8ea81a89dc59848e20e82eaaaea55d8'] = '** (errore) **: nome file non valido';
$_MODULE['<{ets_migrate_connector}prestashop>mcdb_170ce7370e75386945fb88657fbf2fb2'] = '** (errore) **: tipo di file file non valido ';
$_MODULE['<{ets_migrate_connector}prestashop>form_a43a93e2b7e71d1894fbc1aef78bec17'] = 'Fare clic per copiare';
$_MODULE['<{ets_migrate_connector}prestashop>form_a588b1abc58b8b758c4b34b69b9e10bb'] = 'Copiato';
$_MODULE['<{ets_migrate_connector}prestashop>form_32b919d18cfaca89383f6000dcc9c031'] = 'Generare';
$_MODULE['<{ets_migrate_connector}prestashop>admin_a588b1abc58b8b758c4b34b69b9e10bb'] = 'Copiato';
$_MODULE['<{ets_migrate_connector}prestashop>admin_32b919d18cfaca89383f6000dcc9c031'] = 'Generare';
