<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_3a3e4c9b87157ed7f0740d70c2a11a81'] = 'PrestaShop Connector';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_41bc4fc9efb52d522be0cb6e182cf119'] = 'Conecte los sitios web de PrestaShop para fines de migración de datos. Úselo solo para los módulos de migración de PrestaShop hechos por ETS-Soft.';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_7bcc6fa9baad6c804bd18a6a3aa7cf27'] = '¿Está seguro de que desea desinstalar PrestaShop Connector?';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_ab58af4189725736231dd0870254829f'] = 'Habilitar conector';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_2244fb2cc638a8f0d0b9630d51c14779'] = 'URL de la tienda';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_5bc7ab301074148dc708229c5ad54fc6'] = 'Token de acceso';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_0a5fa53f3f20f67f98bd6c3b16df059d'] = 'es obligatorio';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_998b344cff693ad388a14ba89b1523c7'] = 'no es válido';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_a588b1abc58b8b758c4b34b69b9e10bb'] = 'Copiado';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_32b919d18cfaca89383f6000dcc9c031'] = 'Generar';
$_MODULE['<{ets_migrate_connector}prestashop>server_c10817adcfd5543bf91f627f5c9df018'] = 'El módulo PrestaShop Connector no se ha instalado en la tienda de origen';
$_MODULE['<{ets_migrate_connector}prestashop>server_f921a4cd0a24351d45ab036651b78848'] = 'El módulo PrestaShop Connector está desactivado.';
$_MODULE['<{ets_migrate_connector}prestashop>server_d98df3f231696c9ae7e459987ae26256'] = 'El PrestaShop Connector se ha desactivado';
$_MODULE['<{ets_migrate_connector}prestashop>server_7f7dd6a7975afd2cb694aa3ebaef5c90'] = 'El token de acceso no es correcto. ¡Conexión denegada! ';
$_MODULE['<{ets_migrate_connector}prestashop>mcdb_f8ea81a89dc59848e20e82eaaaea55d8'] = '** (error) **: nombre de archivo no válido ';
$_MODULE['<{ets_migrate_connector}prestashop>mcdb_170ce7370e75386945fb88657fbf2fb2'] = '** (error) **: archivo de tipo de archivo no válido ';
$_MODULE['<{ets_migrate_connector}prestashop>form_a43a93e2b7e71d1894fbc1aef78bec17'] = 'Haga clic para copiar';
$_MODULE['<{ets_migrate_connector}prestashop>form_a588b1abc58b8b758c4b34b69b9e10bb'] = 'Copiado';
$_MODULE['<{ets_migrate_connector}prestashop>form_32b919d18cfaca89383f6000dcc9c031'] = 'Generar';
$_MODULE['<{ets_migrate_connector}prestashop>admin_a588b1abc58b8b758c4b34b69b9e10bb'] = 'Copiado';
$_MODULE['<{ets_migrate_connector}prestashop>admin_32b919d18cfaca89383f6000dcc9c031'] = 'Generar';
