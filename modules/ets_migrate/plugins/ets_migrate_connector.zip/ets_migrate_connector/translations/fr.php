<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_3a3e4c9b87157ed7f0740d70c2a11a81'] = 'PrestaShop Connector';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_41bc4fc9efb52d522be0cb6e182cf119'] = 'Connectez les sites Web PrestaShop à des fins de migration de données. Utiliser uniquement pour les modules de migration PrestaShop créés par ETS-Soft';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_7bcc6fa9baad6c804bd18a6a3aa7cf27'] = 'Voulez-vous vraiment désinstaller PrestaShop Connector ?  ';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_ab58af4189725736231dd0870254829f'] = 'Activer le connecteur';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_2244fb2cc638a8f0d0b9630d51c14779'] = 'L’URL de la boutique';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_5bc7ab301074148dc708229c5ad54fc6'] = 'Jeton d\'accès';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_f4f70727dc34561dfde1a3c529b6205c'] = 'Réglages';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_0a5fa53f3f20f67f98bd6c3b16df059d'] = 'est requis';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_998b344cff693ad388a14ba89b1523c7'] = 'n\'est pas valide';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_a588b1abc58b8b758c4b34b69b9e10bb'] = 'Copié';
$_MODULE['<{ets_migrate_connector}prestashop>ets_migrate_connector_32b919d18cfaca89383f6000dcc9c031'] = 'Générer';
$_MODULE['<{ets_migrate_connector}prestashop>server_c10817adcfd5543bf91f627f5c9df018'] = 'Le module PrestaShop Connector n\'a pas été installé sur le magasin source';
$_MODULE['<{ets_migrate_connector}prestashop>server_f921a4cd0a24351d45ab036651b78848'] = 'Le module PrestaShop Connector est désactivé. ';
$_MODULE['<{ets_migrate_connector}prestashop>server_d98df3f231696c9ae7e459987ae26256'] = 'Le module PrestaShop Connector a été désactivé ';
$_MODULE['<{ets_migrate_connector}prestashop>server_7f7dd6a7975afd2cb694aa3ebaef5c90'] = 'Le jeton d\'accès n\'est pas correct. La connexion est refusée! ';
$_MODULE['<{ets_migrate_connector}prestashop>mcdb_f8ea81a89dc59848e20e82eaaaea55d8'] = '** (erreur) ** : nom de fichier invalide';
$_MODULE['<{ets_migrate_connector}prestashop>mcdb_170ce7370e75386945fb88657fbf2fb2'] = '** (erreur) ** : fichier de type de fichier non valide ';
$_MODULE['<{ets_migrate_connector}prestashop>form_a43a93e2b7e71d1894fbc1aef78bec17'] = 'Cliquez pour copier';
$_MODULE['<{ets_migrate_connector}prestashop>form_a588b1abc58b8b758c4b34b69b9e10bb'] = 'Copié';
$_MODULE['<{ets_migrate_connector}prestashop>form_32b919d18cfaca89383f6000dcc9c031'] = 'Générer';
$_MODULE['<{ets_migrate_connector}prestashop>admin_a588b1abc58b8b758c4b34b69b9e10bb'] = 'Copié';
$_MODULE['<{ets_migrate_connector}prestashop>admin_32b919d18cfaca89383f6000dcc9c031'] = 'Générer';
