<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_9879a22790c154d2e21994f9b87f3c47'] = 'PrestaShop Password Keeper';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_1519a9a8f56188e8780e4668a906388a'] = 'Mantenga las contraseñas antiguas cuando migre datos entre sitios web de PrestaShop utilizando el módulo de migración ';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_923cc3fd014742fbc2a3dd76f2a7d8ca'] = 'Se requiere _COOKIE_KEY_ de la página web de origen de PrestaShop';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_c888438d14855d7d96a2724ee9c306bd'] = 'La configuración se ha actualizado';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_51ac4bf63a0c6a9cefa7ba69b4154ef1'] = 'Configuración';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_97e6c933fc6cd2aa1da4a437bb9ea3f7'] = '_COOKIE_KEY_ de la página web de origen de PrestaShop';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_e93ae3213eb3580d882435939808b54b'] = '_COOKIE_KEY_ se proporciona cuando se termina la migración utilizando un módulo de migración. También está disponible en el archivo de configuración (settings.inc.php) de la página web de origen.';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{ets_passwordkeeper}prestashop>form_fa535ffb25e1fd20341652f9be21e06e'] = 'Configurar';
$_MODULE['<{ets_passwordkeeper}prestashop>form_f25b7a4db1d87afa1d07b8c2355acef1'] = '_COOKIE_KEY_ de la página web de origen de PrestaShop';
$_MODULE['<{ets_passwordkeeper}prestashop>form_b17f3f4dcf653a5776792498a9b44d6a'] = 'Ajustes de actualización';
