<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_9879a22790c154d2e21994f9b87f3c47'] = 'PrestaShop Password Keeper';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_1519a9a8f56188e8780e4668a906388a'] = 'Conservez les anciens mots de passe lors de la migration de données entre les sites Web PrestaShop à l\'aide d\'un module de migration';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_923cc3fd014742fbc2a3dd76f2a7d8ca'] = '_COOKIE_KEY_ du site web PrestaShop source est requis';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_c888438d14855d7d96a2724ee9c306bd'] = 'Les paramètres ont été mis à jour ';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_51ac4bf63a0c6a9cefa7ba69b4154ef1'] = 'Paramètres';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_97e6c933fc6cd2aa1da4a437bb9ea3f7'] = '_COOKIE_KEY_ du site web PrestaShop source';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_e93ae3213eb3580d882435939808b54b'] = 'La _COOKIE_KEY_ est fournie lorsque vous terminez la migration en utilisant un module de migration. Elle est également disponible dans le fichier de paramètres (settings.inc.php) du site web source.';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{ets_passwordkeeper}prestashop>form_fa535ffb25e1fd20341652f9be21e06e'] = 'Configurer';
$_MODULE['<{ets_passwordkeeper}prestashop>form_f25b7a4db1d87afa1d07b8c2355acef1'] = '_COOKIE_KEY_ du site web PrestaShop source';
$_MODULE['<{ets_passwordkeeper}prestashop>form_b17f3f4dcf653a5776792498a9b44d6a'] = 'Mettre à jour les paramètres';
