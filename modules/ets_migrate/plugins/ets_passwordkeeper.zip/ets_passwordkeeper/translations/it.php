<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_9879a22790c154d2e21994f9b87f3c47'] = 'PrestaShop Password Keeper';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_1519a9a8f56188e8780e4668a906388a'] = 'Conserva le vecchie password durante la migrazione dei dati tra i siti Web di PrestaShop utilizzando il modulo di migrazione.';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_923cc3fd014742fbc2a3dd76f2a7d8ca'] = 'È richiesta una _COOKIE_KEY_ del sito sorgente';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_c888438d14855d7d96a2724ee9c306bd'] = 'Le impostazioni sono state aggiornate';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_51ac4bf63a0c6a9cefa7ba69b4154ef1'] = 'Impostazioni';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_97e6c933fc6cd2aa1da4a437bb9ea3f7'] = '_COOKIE_KEY_ del sito web PrestaShop sorgente';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_e93ae3213eb3580d882435939808b54b'] = 'Il _COOKIE_KEY_ viene fornito in dotazione quando completi la migrazione usando un modulo di migrazione. È anche disponibile sul file delle impostazioni (settings.inc.php) del sito web sorgente.';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{ets_passwordkeeper}prestashop>form_fa535ffb25e1fd20341652f9be21e06e'] = 'Configurare';
$_MODULE['<{ets_passwordkeeper}prestashop>form_f25b7a4db1d87afa1d07b8c2355acef1'] = '_COOKIE_KEY_ del sito web PrestaShop sorgente';
$_MODULE['<{ets_passwordkeeper}prestashop>form_b17f3f4dcf653a5776792498a9b44d6a'] = 'Aggiorna impostazioni';
